import React from 'react';

const Dashboard = () => {
     return (
          <div>
               this is dashbaord page
          </div>
     );
};

export default Dashboard;